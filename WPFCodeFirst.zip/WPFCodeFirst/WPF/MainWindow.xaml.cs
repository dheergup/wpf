﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace WPF
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        StudentContext st = new StudentContext();
        Student std;
        public MainWindow()
        {
            InitializeComponent();
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            Student std = new Student();
            std.ID = Convert.ToInt32(txtID.Text);
            std.Name = txtName.Text;
            std.Age = Convert.ToInt32(txtAge.Text);
            std.DOB = Convert.ToDateTime(txtDOB.Text);
            st.Stud.Add(std);
            st.SaveChanges();
            MessageBox.Show("Student ADDED");
            txtID.Text = "";
            txtName.Text = "";
            txtAge.Text = "";
            txtDOB.Text = "";
            btnDelete.IsEnabled = false;
            btnUpdate.IsEnabled = false;

        }

        private void btnView_Click(object sender, RoutedEventArgs e)
        {
            var query = from a in st.Stud
                        select a;
            grdView.ItemsSource = query.ToList();
        }

        private void Button_Click_2(object sender, RoutedEventArgs e)
        {
            int id = Convert.ToInt32(txtID.Text);
            var query = (from a in st.Stud
                        where a.ID == id
                        select a).FirstOrDefault();
            if (query != null)
            {
                std = query;
                txtName.Text = std.Name;
                txtAge.Text = std.Age.ToString();
                txtDOB.Text = std.DOB.ToString();
                btnDelete.IsEnabled = true;
                btnUpdate.IsEnabled = true;
            }
            else
            {
                txtID.Text = "";
                txtName.Text = "";
                txtAge.Text = "";
                txtDOB.Text = "";
                btnDelete.IsEnabled = false;
                btnUpdate.IsEnabled = false;
                MessageBox.Show("Student Id not Exist");
            }
        }

        private void Window_Loaded_1(object sender, RoutedEventArgs e)
        {
            btnDelete.IsEnabled = false;
            btnUpdate.IsEnabled = false;
        }

        private void btnDelete_Click(object sender, RoutedEventArgs e)
        {
            st.Stud.Remove(std);
            st.SaveChanges();
            MessageBox.Show("Deleted");
            txtID.Text = "";
            txtName.Text = "";
            txtAge.Text = "";
            txtDOB.Text = "";
            btnDelete.IsEnabled = false;
            btnUpdate.IsEnabled = false;
        }

        private void btnUpdate_Click(object sender, RoutedEventArgs e)
        {
            std.Name = txtName.Text;
            std.Age = Convert.ToInt32(txtAge.Text);
            std.DOB = Convert.ToDateTime(txtDOB.Text);
            st.SaveChanges();
            MessageBox.Show("Student Updated");
            txtID.Text = "";
            txtName.Text = "";
            txtAge.Text = "";
            txtDOB.Text = "";
            btnDelete.IsEnabled = false;
            btnUpdate.IsEnabled = false;
        }
    }
}
