﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SMS.Entity;
using SMS.Exception;
using SMS.DAL;
using System.Text.RegularExpressions;
using System.Data;
using System.Data.SqlClient;

namespace SMS.BLL
{
    public class StudentValidations
    {
        StudentOpeartions soperation = new StudentOpeartions();
       
        public bool ValidateStudent(Student std)
        {
            bool StudentValidated = true;
            StringBuilder sb = new StringBuilder();


            if (std.ID.ToString() == string.Empty)
            {
                StudentValidated = false;
                sb.Append("Student ID must be Provided");

            }
            if (std.Name == string.Empty)
            {
                StudentValidated = false;
                sb.Append("Student Name must be Provided");
            }
            else if (!Regex.IsMatch(std.Name, @"^[a-zA-Z ]+$"))
            {
                StudentValidated = false;
                sb.Append("Student Name must have characters only");
            }

            if (std.Age.ToString() == string.Empty)
            {
                StudentValidated = false; ;
                sb.Append("Student Age must be Provided");
            }

            if (std.City == string.Empty)
            {
                StudentValidated = false;
                sb.Append("City must be Provided");
            }
            else if (std.City.ToLower() != "pune" && std.City.ToLower() != "mumbai" && std.City.ToLower() != "bangalore")
            {
                StudentValidated = false;
                sb.Append("City should be either Pune Or Mumbai Or Bangalore");
            }

            if (std.DOB.ToString() == string.Empty)
            {
                StudentValidated = false;
                sb.Append("Date of Birth must be Provided");
            }

            if (StudentValidated == false)
            {
                throw new StudentException(sb.ToString());
            }
            return StudentValidated;
        }

        public bool AddStudent(Student std)
        {
            bool StudentAdded = false;
            try
            {
                if(ValidateStudent(std))
                {
                 StudentAdded = soperation.AddStudent(std);
                } 
            }
            catch(SqlException ex)
            {
                throw ex;
            }
            catch(StudentException ex)
            {
                throw ex;
            }
            catch(SystemException ex)
            {
                throw ex;
            }
            return StudentAdded;
        }

        public DataTable SearchStudent(int ID)
        {
            DataTable table = new DataTable();
            try
            {
                table = soperation.SearchStudent(ID);
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (StudentException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return table;

        }

        public bool UpdateStudent(Student std)
        {
            bool StudentUpdated = false;
            try
            {
                if (ValidateStudent(std) == true)
                {
                    StudentUpdated = soperation.UpdateStudent(std);
                }
            }
            catch (SqlException ex)
            {

                throw ex;
            }
            catch (StudentException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return StudentUpdated;
        }

        public bool Deletestudent(int ID)
        {
            bool StudentDeleted =  false;
            try
            {
                StudentDeleted = soperation.DeleteStudent(ID);
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (StudentException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return StudentDeleted; 
        }

        public DataTable DisplayStudent()
        {
            DataTable table = new DataTable();
            try 
	        {	        
		        table = soperation.DisplayStudent();
	        }
	        catch (SqlException ex)
	        {
		        throw ex;
	        }
            catch(StudentException ex)
            {
                throw ex;
            }
            catch(SystemException ex)
            {
                throw ex;
            }
            return table;
        }
    }
}

