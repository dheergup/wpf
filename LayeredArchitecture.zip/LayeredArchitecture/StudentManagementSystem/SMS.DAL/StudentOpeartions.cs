﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SMS.Entity;
using SMS.Exception;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;

namespace SMS.DAL
{
    public class StudentOpeartions
    {
        SqlConnection connection;
        SqlCommand command;
        SqlDataReader reader;

        public StudentOpeartions()
        {
            connection = new SqlConnection(ConfigurationManager.ConnectionStrings["Student"].ConnectionString);
        }

        public bool AddStudent(Student stud)
        {
            bool StudentAdded = false;
            try
            {
                command = new SqlCommand("Add_Student", connection);
                command.CommandType = CommandType.StoredProcedure;
                command.Parameters.AddWithValue("@ID", stud.ID);
                command.Parameters.AddWithValue("@Name", stud.Name);
                command.Parameters.AddWithValue("@Age", stud.Age);
                command.Parameters.AddWithValue("@City", stud.City);
                command.Parameters.AddWithValue("@DOB", stud.DOB);
                connection.Open();
                int result = command.ExecuteNonQuery();
                if (result > 0)
                {
                    StudentAdded = true;
                }
            }
            catch (SqlException ex)
            {

                throw ex;
            }
            catch (StudentException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            finally
            {
                connection.Close();
            }
            return StudentAdded;
        }

        public DataTable SearchStudent(int ID)
        {
            DataTable table = new DataTable();
            try
            {
                command=new SqlCommand("Search_Student",connection);
                command.CommandType = CommandType.StoredProcedure;
                command.Parameters.AddWithValue("@ID",ID);
                connection.Open();
                reader = command.ExecuteReader();
                table.Load(reader);
            }
            catch (SqlException ex)
            {
                throw new StudentException("Student ID Does Not Exists");
            }
            catch (StudentException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            finally
            {
                connection.Close(); 
            }
            return table;
        }

        public bool UpdateStudent(Student stud)
        {
            bool StudentUpdated = false;
            try
            {
                command = new SqlCommand("Update_Student", connection);
                command.CommandType = CommandType.StoredProcedure;
                command.Parameters.AddWithValue("@ID", stud.ID);
                command.Parameters.AddWithValue("@Name", stud.Name);
                command.Parameters.AddWithValue("@Age", stud.Age);
                command.Parameters.AddWithValue("@City", stud.City);
                command.Parameters.AddWithValue("@DOB", stud.DOB);
                connection.Open();
                int result = command.ExecuteNonQuery();
                if (result > 0)
                {
                    StudentUpdated = true;
                }
            }
            catch (SqlException ex)
            {

                throw ex;
            }
            catch (StudentException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            finally
            {
                connection.Close();
            }
            return StudentUpdated;
        }

        public bool DeleteStudent(int ID)
        {
            bool StudentDeleted = false;
            try
            {
                command = new SqlCommand("Delete_Student", connection);
                command.CommandType = CommandType.StoredProcedure;
                command.Parameters.AddWithValue("@ID", ID);
                connection.Open();
                int result = command.ExecuteNonQuery();
                if (result > 0)
                {
                    StudentDeleted = true;
                }
            }
            catch (SqlException ex)
            {

                throw ex;
            }
            catch (StudentException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            finally
            {
                connection.Close();
            }
            return StudentDeleted;
        }

        public DataTable DisplayStudent()
        {
            DataTable table = new DataTable();
            try
            {
                command=new SqlCommand("Display_Student",connection);
                command.CommandType = CommandType.StoredProcedure;
                connection.Open();
                reader = command.ExecuteReader();
                table.Load(reader);
            }
            catch (SqlException ex)
            {

                throw ex;
            }
            catch (StudentException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            finally
            {
                connection.Close(); 
            }
            return table;
        }
   }
}
