﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using SMS.Entity;
using SMS.Exception;
using SMS.BLL;
using System.Data.SqlClient;

namespace SMS.PL
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

       StudentValidations svalidation = new StudentValidations();

       private void btnAdd_Click(object sender, EventArgs e)
        {
            try
            {
                Student stud = new Student();
                bool isNumber;
                int result;
                isNumber = int.TryParse(txtID.Text, out result);
                if (isNumber)
                    stud.ID = result;
                else
                {
                    MessageBox.Show("Student ID Must Contain Number", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }

                stud.Name = txtName.Text;

                isNumber = int.TryParse(txtAge.Text, out result);
                if (isNumber)
                    stud.Age = result;
                else
                {
                    MessageBox.Show("Student Age Must Contain Number", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }

                stud.City = txtCity.Text;
                System.Globalization.CultureInfo enGB = new System.Globalization.CultureInfo("ja-JP");
                stud.DOB = Convert.ToDateTime(txtDob.Text, enGB);

                bool flag = svalidation.AddStudent(stud);
                if (flag == true)
                {
                    MessageBox.Show("New Student Record Added");
                    txtID.Text = "";
                    txtName.Text = "";
                    txtAge.Text = "";
                    txtCity.Text = "";
                    txtDob.Text = "";
                }
            }
            catch (SqlException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (StudentException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (SystemException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void btnSearch_Click(object sender, EventArgs e)
        {
            DataTable table = new DataTable();
            DataSet dset = new DataSet();

            bool isNumber;
            int result;
            int ID;

            isNumber = int.TryParse(txtStdID.Text, out result);
            if (isNumber)
                ID = result;
            else
            {
                MessageBox.Show("Student ID Must Contain Number", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            table = svalidation.SearchStudent(ID);
            try
            {
                if (table != null)
                {
                    dset.Tables.Add(table);
                    txtStdName.Text = dset.Tables[0].Rows[0][1].ToString();
                    txtStdAge.Text = dset.Tables[0].Rows[0][2].ToString();
                    txtStdCity.Text = dset.Tables[0].Rows[0][3].ToString();
                    txtStdDOB.Text = dset.Tables[0].Rows[0][4].ToString();
                    btnUpdate.Enabled = true;
                    btnDelete.Enabled = true;
                }
            }
            catch (SqlException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (StudentException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (SystemException ex)
            {
                txtStdID.Text = "";
                txtStdName.Text = "";
                txtStdAge.Text = "";
                txtStdCity.Text = "";
                txtStdDOB.Text = "";
                btnDelete.Enabled = false;
                btnUpdate.Enabled = false;
                MessageBox.Show("Id Not Exist");
            }
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            try
            {
                Student stud = new Student();
                bool isNumber;
                int result;

                isNumber = int.TryParse(txtStdID.Text, out result);
                if (isNumber)
                    stud.ID = result;
                else
                {
                    MessageBox.Show("Student Age must be Number", "Error", MessageBoxButtons.OK,MessageBoxIcon.Error);
                    return;
                }
                stud.Name = txtStdName.Text;
                stud.Age = Convert.ToInt32(txtStdAge.Text);
                stud.City = txtStdCity.Text;
                stud.DOB = Convert.ToDateTime(txtStdDOB.Text);

                bool flag = svalidation.UpdateStudent(stud);

                if (flag == true)
                {
                    MessageBox.Show("Student Details Updated Successfully");
                    txtStdID.Text = "";
                    txtStdName.Text = "";
                    txtStdAge.Text = "";
                    txtStdCity.Text = "";
                    txtStdDOB.Text = "";
                    btnDelete.Enabled = false;
                    btnUpdate.Enabled = false;
                        }
            }
            catch (SqlException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (StudentException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (SystemException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            try
            {
                bool isNumber;
                int result;
                int ID;

                isNumber = int.TryParse(txtStdID.Text, out result);
                if (isNumber)
                    ID = result;
                else
                {
                    MessageBox.Show("Student Id must contain Numbers Only", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }

                bool flag = svalidation.Deletestudent(ID);
                if (flag == true)
                {
                    MessageBox.Show("Student Record Deleted Successfully");
                    txtStdID.Text = "";
                    txtStdName.Text = "";
                    txtStdAge.Text = "";
                    txtStdCity.Text = "";
                    txtStdDOB.Text = "";
                    btnDelete.Enabled = false;
                    btnUpdate.Enabled = false;
                   
               }
            }
            catch (SqlException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (StudentException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (SystemException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void btnDisplay_Click(object sender, EventArgs e)
        {
            try
            {
                DataTable table = new DataTable();
                table = svalidation.DisplayStudent();
                grdView.DataSource = table;
            }
            catch (SqlException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (StudentException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (SystemException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            btnUpdate.Enabled = false;
            btnDelete.Enabled = false;
        }

        private void tabPage2_Click(object sender, EventArgs e)
        {

        }
    }
}
