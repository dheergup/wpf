﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace WpfApplication1
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        Training_18Jan2017_TalwadeEntities en = new Training_18Jan2017_TalwadeEntities();
        Employee obj=new Employee();
        public MainWindow()
        {
            InitializeComponent();
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            
            var query = from a in en.Employees
                        select a;
            grdView.ItemsSource = query.ToList();
        }

        private void Button_Click_2(object sender, RoutedEventArgs e)
        {
            obj.Employee_Number = Convert.ToInt32(txtID.Text);
            obj.Employee_Name = txtName.Text;
            obj.Department_Number = Convert.ToInt32(txtDep.Text);
            obj.Salary = Convert.ToDouble(txtSal.Text);
            obj.Region = txtReg.Text;
            en.AddToEmployees(obj);
            en.SaveChanges();
            MessageBox.Show("Employee Inserted");
        }
    }
}
