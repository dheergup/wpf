﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using SMS.BLL;
using SMS.Entity;
using System.Data;
using System.Data.SqlClient;
using SMS.Exception;
namespace SMS.PL
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        StudentValidation svalidate = new StudentValidation();
        private void btnAdd_Click(object sender, EventArgs e)
        {
            try
            {
                bool isNumber;
                int result;
                Student std = new Student();
                isNumber = int.TryParse(txtID.Text, out result);
                if (isNumber)
                    std.ID = result;
                else
                {
                    MessageBox.Show("Student ID Must Contain Number", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }
                std.Name = txtName.Text;
                isNumber = int.TryParse(txtAge.Text, out result);
                if (isNumber)
                    std.Age = result;
                else
                {
                    MessageBox.Show("Student Age must be Number", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }
                std.City = txtCity.Text;
                std.DOB = Convert.ToDateTime(txtDOB.Text);
                bool flag=svalidate.AddStudent(std);
                if(flag==true)
                {
                    MessageBox.Show("Student Added");
                }
            }
            catch (SqlException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (StudentException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (SystemException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void btnDisplay_Click(object sender, EventArgs e)
        {
            try
            {
                DataTable table = new DataTable();
                table = svalidate.DisplayStudent();
                grdView.DataSource = table;
            }
            catch (SqlException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (StudentException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (SystemException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            btnDelete.Enabled = false;
            btnUpdate.Enabled = false;
        }

        private void btnSearch_Click(object sender, EventArgs e)
        {
            try
            {
                DataTable table = new DataTable();
                DataSet ds = new System.Data.DataSet();
                bool isNumber;
                int result;
                int ID;
                isNumber = int.TryParse(txtID.Text, out result);
                if (isNumber)
                    ID = result;
                else
                {
                    MessageBox.Show("Student ID Must Contain Number", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }
                table=svalidate.SearchStudent(ID);
                if (table != null)
                {
                    ds.Tables.Add(table);
                    txtName.Text = ds.Tables[0].Rows[0][1].ToString();
                    txtAge.Text = ds.Tables[0].Rows[0][2].ToString();
                    txtCity.Text = ds.Tables[0].Rows[0][3].ToString();
                    txtDOB.Text = ds.Tables[0].Rows[0][4].ToString();
                    btnDelete.Enabled = true;
                    btnUpdate.Enabled = true;
                }
                else
                {

                }
                
            }
            catch (SqlException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (StudentException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (SystemException ex)
            {
                MessageBox.Show("Student Id Not Exist");
                txtID.Text = "";
                txtName.Text = "";
                txtCity.Text = "";
                txtAge.Text = "";
                txtDOB.Text = "";
                txtID.Focus();
                btnUpdate.Enabled = false;
                btnDelete.Enabled = false;
            }
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            try
            {
                bool isNumber;
                int result;
                int ID;
                isNumber = int.TryParse(txtID.Text, out result);
                if (isNumber)
                    ID = result;
                else
                {
                    MessageBox.Show("Student ID Must Contain Number", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }
                bool flag = svalidate.DeleteStudent(ID);
                if (flag)
                {
                    MessageBox.Show("Student Deleted");
                }
            }
            catch (SqlException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (StudentException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (SystemException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            try
            {
                bool isNumber;
                int result;
                Student std = new Student();
                isNumber = int.TryParse(txtID.Text, out result);
                if (isNumber)
                    std.ID = result;
                else
                {
                    MessageBox.Show("Student ID Must Contain Number", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }
                std.Name = txtName.Text;
                isNumber = int.TryParse(txtAge.Text, out result);
                if (isNumber)
                    std.Age = result;
                else
                {
                    MessageBox.Show("Student Age must be Number", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }
                std.City = txtCity.Text;
                std.DOB = Convert.ToDateTime(txtDOB.Text);
                bool flag = svalidate.UpdateStudent(std);
                if (flag == true)
                {
                    MessageBox.Show("Student Updated");
                }
            }
            catch (SqlException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (StudentException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (SystemException ex)
            {
                MessageBox.Show(ex.Message);
            } 
        }
    }
}
