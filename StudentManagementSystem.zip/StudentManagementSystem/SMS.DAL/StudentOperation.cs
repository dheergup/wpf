﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using SMS.Entity;
using SMS.Exception;

namespace SMS.DAL
{
    public class StudentOperation
    {
        SqlConnection connection;
        SqlCommand cmd;
        SqlDataReader reader;
        DataSet ds;
        public StudentOperation()
        {
            connection = new SqlConnection(ConfigurationManager.ConnectionStrings["Student"].ConnectionString);
        }
        public bool AddStudent(Student std)
        {
            bool studentAdded = false;
            try
            {
                cmd = new SqlCommand("AddStud", connection);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@ID", std.ID);
                cmd.Parameters.AddWithValue("@Name", std.Name);
                cmd.Parameters.AddWithValue("@Age", std.Age);
                cmd.Parameters.AddWithValue("@City", std.City);
                cmd.Parameters.AddWithValue("@DOB", std.DOB);
                connection.Open();
                int result = cmd.ExecuteNonQuery();
                if (result > 0)
                {
                    studentAdded = true;
                }
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (StudentException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            finally
            {
                connection.Close();
            }
            return studentAdded;
        }

        public bool DeleteStudent(int ID)
        {
            bool studentDeleted = false;
            try
            {
                cmd = new SqlCommand("DelStud",connection);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@ID", ID);
                connection.Open();
                int result = cmd.ExecuteNonQuery();
                if (result > 0)
                {
                    studentDeleted = true;
                }
            }
            catch (StudentException ex)
            {

                throw ex;
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            
            finally
            {
                connection.Close();
            }
            return studentDeleted;

        }
        public DataTable DislpayStudent()
        {
            DataTable table = new DataTable();
            try
            {
                cmd = new SqlCommand("DisStud",connection);
                cmd.CommandType = CommandType.StoredProcedure;
                connection.Open();
                reader = cmd.ExecuteReader();
                table.Load(reader);
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (StudentException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {

                throw ex;
            }
            finally
            {
                connection.Close();
            }
            return table;
        }
        public DataTable SearchStudent(int ID)
        {
            DataTable table = new DataTable();
            try
            {
                cmd = new SqlCommand("SearchStud", connection);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@ID",ID);
                connection.Open();
                reader = cmd.ExecuteReader();
                table.Load(reader);
            }
            catch (SqlException ex)
            {
                throw new StudentException("Student Id Not foundS");
            }
            catch (StudentException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {

                throw ex;
            }
            finally
            {
                connection.Close();
            }
            return table;
        }
        public bool UpdateStudent(Student std)
        {
            bool studentUpdated = false;
            try
            {
                cmd = new SqlCommand("UpdateStud", connection);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@ID", std.ID);
                cmd.Parameters.AddWithValue("@Name", std.Name);
                cmd.Parameters.AddWithValue("@Age", std.Age);
                cmd.Parameters.AddWithValue("@City", std.City);
                cmd.Parameters.AddWithValue("@DOB", std.DOB);
                connection.Open();
                int result = cmd.ExecuteNonQuery();
                if (result > 0)
                {
                    studentUpdated = true;
                }
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (StudentException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {

                throw ex;
            }
            finally
            {
                connection.Close();
            }
            return studentUpdated;
        }
    }
}
