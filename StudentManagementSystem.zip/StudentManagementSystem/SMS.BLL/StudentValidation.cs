﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SMS.Entity;
using SMS.Exception;
using SMS.DAL;
using System.Data.SqlClient;
using System.Text.RegularExpressions;
using System.Data;

namespace SMS.BLL
{
    public class StudentValidation
    {
        StudentOperation soperation=new StudentOperation();
        public bool ValidateStudent(Student std)
        {
            StringBuilder sb = new StringBuilder();
            bool studentValidated = true;
            if (std.ID.ToString() == String.Empty)
            {
                studentValidated = false;
                sb.Append("Student ID is Required\n");
            }
            if (std.Name == String.Empty)
            {
                studentValidated = false;
                sb.Append("Student Name cannot be Empty");
            }
            else if (!Regex.IsMatch(std.Name, @"^[a-zA-Z ]+$"))
            {
                studentValidated = false;
                sb.Append("Student Name Sholud have only character");
            }
            if (std.DOB.ToString() == String.Empty)
            {
                studentValidated = false;
                sb.Append("DAte of Birth Cannot BE Empty");
            }
            if (std.City == String.Empty)
            {
                studentValidated = false;
                sb.Append("City cannot be empty");
            }
            else if (std.City != "Mumbai" && std.City != "Chennai" && std.City != "Pune")
            {
                studentValidated = false;
                sb.Append("City cannot be Mumbai Pune or Chennai");
            }
            if(std.Age.ToString()== String.Empty)
            {
                studentValidated = false;
                sb.Append("Age Cannot Be Empty");
            }
            if (studentValidated == false)
            {
                throw new StudentException(sb.ToString());
            }
            return studentValidated;
        }
        public bool AddStudent(Student std)
        {
            bool studentAdded = false;
            try
            {
                if (ValidateStudent(std) == true)
                {
                   studentAdded = soperation.AddStudent(std);
                }
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (StudentException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return studentAdded;
        }
        public bool DeleteStudent(int ID)
        {
            bool studentDeleted = false;
            try
            {
                studentDeleted = soperation.DeleteStudent(ID);
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (StudentException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return studentDeleted;
        }
        public bool UpdateStudent(Student std)
        {
            bool studentUpdated = false;
            try
            {
                if (ValidateStudent(std) == true)
                {
                    studentUpdated = soperation.UpdateStudent(std);
                }
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (StudentException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return studentUpdated;
        }
        public DataTable DisplayStudent()
        {
            DataTable table = new DataTable();
            try
            {
                table=soperation.DislpayStudent();
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (StudentException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return table;
        }
        public DataTable SearchStudent(int ID)
        {
            DataTable table = new DataTable();
            try
            {
                table = soperation.SearchStudent(ID);
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (StudentException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return table;
        }
    }
}
